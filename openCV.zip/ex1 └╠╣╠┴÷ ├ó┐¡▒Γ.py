import cv2
img=cv2.imread('./input.jpg')
cv2.imshow('asvd',img)
cv2.waitKey()
